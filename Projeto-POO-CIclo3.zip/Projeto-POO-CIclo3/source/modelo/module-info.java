module banco_projeto_disciplina {
	requires java.sql;
}